package com.zsmx.vod.controller;


import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 课程 前端控制器
 * </p>
 *
 * @author zsmx
 * @since 2024-01-08
 */
@Tag(name = "章节管理")
@RestController
@RequestMapping("/vod/chapter")
public class ChapterController {

}

