package com.zsmx.vod.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zsmx.model.vod.Course;
import com.zsmx.result.Result;
import com.zsmx.vo.vod.CourseFormVo;
import com.zsmx.vo.vod.CourseQueryVo;
import com.zsmx.vod.service.CourseService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.ibatis.annotations.Update;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * <p>
 * 课程 前端控制器
 * </p>
 *
 * @author zsmx
 * @since 2024-01-08
 */
@Tag(name = "课程管理接口")
@RestController
@RequestMapping("/admin/vod/course")
@CrossOrigin
public class CourseController {
    @Autowired
    private CourseService courseService;

    @Operation(summary = "获取分页列表")
    @GetMapping("/getPageList/{page}/{limit}")
    public Result getPageList(
            @Parameter(name = "page",description = "当前页码",required = true)
            @PathVariable Long page,
            @Parameter(name = "limit",description = "每页记录数",required = true)
            @PathVariable Long limit,
            @Parameter(name = "courseVo",description = "查询对象vo",required = false)
            CourseQueryVo courseQueryVo) {
        //mybatis的page分页
        Page<Course> pageParam = new Page<>(page,limit);
        Map<String,Object> map = courseService.findPage(pageParam,courseQueryVo);
        return Result.ok(map);
    }
    //添加课程基本信息
    @Operation(summary = "save-增加课程基本信息")
    @PostMapping("save")
    public Result save(@RequestBody CourseFormVo courseFormVo){
        Long courseId = courseService.saveCourseInfo(courseFormVo);
        return Result.ok(courseId);
    }

    //根据id获取课程信息
    @Operation(summary = "根据id获取课程信息")
    @GetMapping("get/{id}")
    public Result get(@PathVariable Long id){
        CourseFormVo course = courseService.getCourseFormVoById(id);
        return Result.ok(course);
    }
    //根据id修改课程信息
    @Operation(summary = "根据id修改课程信息")
    @PutMapping("update")
    public Result updateById(@RequestBody CourseFormVo courseFormVo){
        courseService.updateCourseId(courseFormVo);
        return Result.ok(courseFormVo);
    }

}

