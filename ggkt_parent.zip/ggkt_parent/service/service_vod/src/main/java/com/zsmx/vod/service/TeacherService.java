package com.zsmx.vod.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zsmx.model.vod.Teacher;

/**
 * <p>
 * 讲师 服务类
 * </p>
 *
 * @author zsmx
 * @since 2023-12-30
 */
public interface TeacherService extends IService<Teacher> {

}
