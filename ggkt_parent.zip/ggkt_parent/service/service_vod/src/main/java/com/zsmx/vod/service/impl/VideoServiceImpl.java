package com.zsmx.vod.service.impl;

import com.zsmx.model.vod.Video;
import com.zsmx.vod.mapper.VideoMapper;
import com.zsmx.vod.service.VideoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 课程视频 服务实现类
 * </p>
 *
 * @author zsmx
 * @since 2024-01-08
 */
@Service
public class VideoServiceImpl extends ServiceImpl<VideoMapper, Video> implements VideoService {

}
