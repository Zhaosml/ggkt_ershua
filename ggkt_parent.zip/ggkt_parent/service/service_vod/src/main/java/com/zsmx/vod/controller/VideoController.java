package com.zsmx.vod.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 课程视频 前端控制器
 * </p>
 *
 * @author zsmx
 * @since 2024-01-08
 */
@RestController
@RequestMapping("/vod/video")
public class VideoController {

}

