package com.zsmx.vod.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zsmx.model.vod.Chapter;

/**
 * <p>
 * 课程 服务类
 * </p>
 *
 * @author zsmx
 * @since 2024-01-08
 */
public interface ChapterService extends IService<Chapter> {

}
