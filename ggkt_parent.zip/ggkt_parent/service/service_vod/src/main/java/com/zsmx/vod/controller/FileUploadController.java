package com.zsmx.vod.controller;

import com.zsmx.result.Result;
import com.zsmx.vod.service.FileService;
import io.prometheus.client.Summary;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author 钊思暮想
 * @date 2024/1/6 12:27
 */
@Tag(name="文件上传")
@RestController
@RequestMapping("/admin/vod/file")
@CrossOrigin
public class FileUploadController {
    @Autowired
    private FileService fileService;

    @Operation(summary = "文件上传")
    @PostMapping("upload")
    public Result upload(@Parameter MultipartFile file){
        String upload = fileService.upload(file);
        return Result.ok(upload).message("上传成功");
    }
}
